import { getElement } from '../utils.js';
import display from '../displayProducts.js';
const setupSearch = () => {};

export default setupSearch;
